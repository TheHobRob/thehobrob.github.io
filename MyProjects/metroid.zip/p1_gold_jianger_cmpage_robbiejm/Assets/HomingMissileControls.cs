﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HomingMissileControls : MonoBehaviour
{
    Rigidbody rigidbody;

    public float moveSpeed = 1f;

    private float h = 0;
    private float v = 0;

    // Start is called before the first frame update
    void Start()
    {
        rigidbody = this.GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 newVelocity = rigidbody.velocity;
        h = 0;
        v = 0;
        if (Input.GetKey(KeyCode.RightArrow))
            h = 1; 
        if (Input.GetKey(KeyCode.LeftArrow))
            h = -1;
        if (Input.GetKey(KeyCode.UpArrow))
            v = 1;
        if (Input.GetKey(KeyCode.DownArrow))
            v = -1;
        newVelocity.x = h * moveSpeed;
        newVelocity.y = v * moveSpeed;

        rigidbody.velocity = newVelocity;

        // Change rotation base on input
        transform.eulerAngles = GetRotation();
    }

    private Vector3 GetRotation() {
        Vector3 rotateTo;
        if (Input.GetKey(KeyCode.RightArrow)) {
            if (Input.GetKey(KeyCode.UpArrow)) {
                rotateTo = new Vector3(0, 0, 45);
            } else if (Input.GetKey(KeyCode.DownArrow)) {
                rotateTo = new Vector3(0, 0, -45);
            } else {
                rotateTo = new Vector3(0, 0, 0);
            }
        } 
        else if (Input.GetKey(KeyCode.LeftArrow)) {
            if (Input.GetKey(KeyCode.UpArrow)) {
                rotateTo = new Vector3(0, 0, 135);
            } else if (Input.GetKey(KeyCode.DownArrow)) {
                rotateTo = new Vector3(0, 0, -135);
            } else {
                rotateTo = new Vector3(0, 0, -180);
            }
        }
        else { // at 0
            if (Input.GetKey(KeyCode.UpArrow))  {
                rotateTo = new Vector3(0, 0, 90);
            } else if (Input.GetKey(KeyCode.DownArrow)) {
                rotateTo = new Vector3(0, 0, -90);
            } else {
                rotateTo = transform.eulerAngles;
            }
        }
        return rotateTo;
    }
}
