﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(AudioSource))]
public class PlaySoundOnTrigger : MonoBehaviour
{
    public AudioClip clip;

    private void OnTriggerEnter(Collider collider) {
        if (collider.tag != "Bullet") return;
        
        AudioSource source = this.GetComponent<AudioSource>();
        source.clip = clip;
        source.Play();
    }
}
