﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnablePlayerControlsOnDestroy : MonoBehaviour
{
    public AudioClip clip; // Set this in inspector

    void OnTriggerEnter(Collider other)
    {
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        player.GetComponent<PlayerHorizontalControl>().enabled = true;
        player.GetComponent<PlayerJump>().enabled = true;
        player.GetComponent<PlayerDirection>().enabled = true;
        player.GetComponent<PlayerState>().enabled = true;
        player.GetComponent<PlayerWeapon>().enabled = true;
        
        GameObject grounded = player.transform.GetChild(0).gameObject;
        grounded.GetComponent<ChooseGroundedSprite>().enabled = true;

        if (clip != null) {
            Camera.main.GetComponent<AudioSource>().PlayOneShot(clip);
        }
        Destroy(this.gameObject);
    }
}
