﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DisablePlayerControlsOnEnable : MonoBehaviour
{
    void Start()
    {
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        player.GetComponent<PlayerHorizontalControl>().enabled = false;
        player.GetComponent<PlayerJump>().enabled = false;
        player.GetComponent<PlayerDirection>().enabled = false;
        player.GetComponent<PlayerState>().enabled = false;
        player.GetComponent<PlayerWeapon>().enabled = false;

        for (int i = 0; i < player.transform.childCount; i++)
        {
            player.transform.GetChild(i).gameObject.SetActive(false);
        }
        GameObject grounded = player.transform.GetChild(0).gameObject;
        grounded.SetActive(true);
        grounded.GetComponent<ChooseGroundedSprite>().enabled = false;
    }
}
