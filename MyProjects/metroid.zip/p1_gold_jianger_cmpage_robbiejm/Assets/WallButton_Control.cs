﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallButton_Control : MonoBehaviour
{
    public GameObject Door;
    private Collider col;
    void Start() {
        col = this.GetComponent<Collider>();
    }
    
    public void OnTriggerEnter() {
        Door.SetActive(false);
        Destroy(this.gameObject);
    }
}
