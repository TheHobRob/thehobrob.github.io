using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerJump : MonoBehaviour
{
    Rigidbody rigid;
    Collider col;
    PlayerHorizontalControl playerHorizontalControl;
    PlayerState playerState;
    AudioSource source;

    InLava lavaComp;

    public float jumpPower = 12;
    public float fallPower = 1;

    private bool ascending = false;

    void Awake()
    {
        rigid = this.GetComponentInParent<Rigidbody>();
        col = this.GetComponent<Collider>();
        playerHorizontalControl = this.GetComponent<PlayerHorizontalControl>();
        playerState = this.GetComponent<PlayerState>();
        lavaComp = this.GetComponent<InLava>();
        source = this.GetComponent<AudioSource>();
    }

    void Update()
    {
        if (playerState.GetState() == PlayerState.State.MORPHBALL) return;

        // Debug.Log("IsGrounded:" + IsGrounded() + " jump: " + Input.GetKeyDown(KeyCode.X).ToString());
        Vector3 newVelocity = rigid.velocity;

        if ((Input.GetKeyDown(KeyCode.X) || Input.GetKeyDown(KeyCode.Slash)) && 
            (playerState.GetState() == PlayerState.State.GROUNDED || lavaComp.GetInLava())) {
            newVelocity.y = jumpPower;
            playerState.SetState(PlayerState.State.JUMP);
            source.Play();
            if (newVelocity.x != 0) {
                playerHorizontalControl.SetRunJumping(true);
                // Debug.Log("Run Jumping: " + true);
            }
            ascending = true;
        }

        if (newVelocity.y <= 0) {
            ascending = false;
        }
        
        if ((Input.GetKeyUp(KeyCode.X) || Input.GetKeyUp(KeyCode.Slash)) && ascending) {
            newVelocity.y = 0f;
            ascending = false;
        }

        rigid.velocity = newVelocity;
    }
}
