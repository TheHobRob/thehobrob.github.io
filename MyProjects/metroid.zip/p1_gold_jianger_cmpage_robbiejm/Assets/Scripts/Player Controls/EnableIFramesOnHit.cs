﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnableIFramesOnHit : MonoBehaviour
{
    HasHealth health;
    SpriteRenderer sprite;
    public float IFrameDeltaTime = 0.1f;
    public float IFrameDurationSeconds = 1f;

    void Start() {
        health = GetComponent<HasHealth>();
        if (health == null) {
            health = this.GetComponentInParent<HasHealth>();
        }

        sprite = this.GetComponent<SpriteRenderer>();
        if (sprite == null) {
            sprite = this.GetComponentInChildren<SpriteRenderer>();
        }
    }
    
    public IEnumerator BecomeTemporarilyInvincible()
    {
        health.SetIsInvincible(true);
        Color original = sprite.color;
        sprite.color = Color.red;
        for (float i = 0; i < IFrameDurationSeconds; i += IFrameDeltaTime)
        {
            yield return new WaitForSeconds(IFrameDeltaTime);
        }
        health.SetIsInvincible(false);
        sprite.color = original;
    }
}
