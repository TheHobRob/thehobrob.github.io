﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerWeapon : MonoBehaviour {
    PlayerDirection playerDirection;
    PlayerInventory playerInventory;

    public GameObject normalbulletPrefab;
    public GameObject missilePrefab;
    public GameObject homingMissilePrefab;

    public float firingSpeed = 10f;

    private GameObject currentWeapon; // For future uses if we have different types of bullets.
    public bool missileOn = false;
    public bool homingMissileOn = false;

    private WeaponConfig weaponConfig;

    Rigidbody rigidbody;

    void Start() {
        playerInventory = this.GetComponent<PlayerInventory>();
        playerDirection = this.GetComponent<PlayerDirection>();
        ResetWeapon();
        currentWeapon = normalbulletPrefab;
        rigidbody = this.GetComponent<Rigidbody>();
    }

    void Update() {
        WeaponConfig[] configs = this.GetComponentsInChildren<WeaponConfig>();
        if (configs.Length == 0) return;
        weaponConfig = configs[0];

        if (playerInventory.HasLongBeam()) {
            normalbulletPrefab.GetComponent<DestroyOnTime>().enabled = false;
            normalbulletPrefab.GetComponent<DestroyWhenOffCamera>().enabled = true;
        }

        ChooseWeapon();

        if (Input.GetKeyDown(KeyCode.Z) || Input.GetKeyDown(KeyCode.Period)) {
            if (missileOn == true && GameManager.isGodMode == false) {
                if (playerInventory.MissileCount() <= 0) {
                    return;
                } else {
                    playerInventory.ChangeNumberOfMissile(-1);
                }
            }

            if (homingMissileOn && rigidbody.velocity.x != 0)
                return; 

            GameObject bulletInstance = GameObject.Instantiate(currentWeapon);
            PositionAndFireWeapon(bulletInstance);
        }
    }

    void ChooseWeapon() {
        /* Toggle Homing Missile */
        if (playerInventory.HasHomingMissile() && Input.GetKeyDown(KeyCode.Alpha0) && !homingMissileOn) {
            SetWeapon(Weapon.HOMING);
        } else if (Input.GetKeyDown(KeyCode.Alpha0) && homingMissileOn) {
            SetWeapon(Weapon.NORMAL);
        }

        /* Toggle missiles */
        if ((Input.GetKeyDown(KeyCode.LeftShift) && missileOn == false) && (playerInventory.HasMissile() || GameManager.isGodMode)) {
            SetWeapon(Weapon.MISSILE);
        } else if (Input.GetKeyDown(KeyCode.LeftShift) && missileOn == true) {
            SetWeapon(Weapon.NORMAL);
        }
    }

    void PositionAndFireWeapon(GameObject bulletInstance) {
        if (playerDirection.IsLookingUp()) {
            weaponConfig.spriteRenderer.sprite = weaponConfig.shootingUpwardPrefab;
            bulletInstance.transform.position = weaponConfig.firingPositionUpward.position;
            bulletInstance.transform.eulerAngles = new Vector3(0, 0, 90);
            bulletInstance.GetComponent<Rigidbody>().velocity = Vector3.up * firingSpeed;
        }
        else {
            weaponConfig.spriteRenderer.sprite = weaponConfig.shootingForwardPrefab;
            bulletInstance.transform.position = weaponConfig.firingPositionForward.position;
            if (playerDirection.IsFacingRight()) {
                bulletInstance.transform.eulerAngles = new Vector3(0, 0, 0);
                bulletInstance.GetComponent<Rigidbody>().velocity = Vector3.right * firingSpeed;
            }
            else {
                bulletInstance.transform.eulerAngles = new Vector3(0, 0, 180);
                bulletInstance.GetComponent<Rigidbody>().velocity = Vector3.left * firingSpeed;
            }
        }
    }

    void SetWeapon(Weapon weapon) {
        homingMissileOn = false;
        missileOn = false;
        if (weapon == Weapon.HOMING) {
            homingMissileOn = true;
            currentWeapon = homingMissilePrefab;
        } else if (weapon == Weapon.MISSILE) {
            missileOn = true;
            currentWeapon = missilePrefab;
        } else {
            currentWeapon = normalbulletPrefab;
        }
    }

    void ResetWeapon() {
        normalbulletPrefab.GetComponent<DestroyOnTime>().enabled = true;
        normalbulletPrefab.GetComponent<DestroyWhenOffCamera>().enabled = false;
    }

    enum Weapon {
        HOMING, MISSILE, NORMAL
    }
}
