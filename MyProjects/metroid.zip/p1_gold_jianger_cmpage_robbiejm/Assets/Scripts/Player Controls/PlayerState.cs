using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerState : MonoBehaviour
{
    PlayerInventory playerInventory;
    PlayerHorizontalControl playerHorizontalControl;
    public GameObject grounded;
    public GameObject morphed;
    public GameObject jump;

    State state = State.GROUNDED;

    // We can do this.GetComponentInChildren<Collider>(), but this is expensive. 
    // Presetting it avoids a speed issue from calling GetComponent in Updates().
    Collider standingCollider;
    Collider morphedCollider;
    Collider jumpCollider;

    void Awake()
    {
        playerInventory = this.GetComponent<PlayerInventory>();
        standingCollider = grounded.GetComponent<Collider>();
        morphedCollider = morphed.GetComponent<Collider>();
        jumpCollider = jump.GetComponent<Collider>();
        playerHorizontalControl = this.GetComponent<PlayerHorizontalControl>();
    }

    // Basically a state machine
    void Update()
    {
        if (state == State.GROUNDED) {
            // Standing -> Morphball
            if (Input.GetKeyDown(KeyCode.DownArrow) && playerInventory.HasMorphBall()) {
                SetState(State.MORPHBALL);
            }
            // Standing -> Jump set in PlayerJump
            else if (!IsGrounded()) {
                SetState(State.JUMP);
            }
        }
        else if (state == State.MORPHBALL) {
             // Morphball -> Standing
            if ((Input.GetKeyDown(KeyCode.X) || Input.GetKeyDown(KeyCode.UpArrow)) && CanStand()) {
                SetState(State.GROUNDED);
            }
        }
    }

    public State GetState() {
        return this.state;
    }

    public void SetState(State state) {
        grounded.SetActive(false);
        morphed.SetActive(false);
        jump.SetActive(false);
        if (state == State.GROUNDED) {
            grounded.SetActive(true);
        }
        else if (state == State.MORPHBALL) {
            morphed.SetActive(true);
        }
        else if (state == State.JUMP) {
            jump.SetActive(true);
        }
        this.state = state;
    }

    public Collider GetCollider() {
        if (state == State.GROUNDED)
            return standingCollider;
        else if (state == State.MORPHBALL)
            return morphedCollider;
        else if (state == State.JUMP) {
            return jumpCollider;
        }

        return null;
    }

    void OnCollisionEnter(Collision other) {
        // Debug.Log("Contact points:" + other.contactCount.ToString());
        if (other.contactCount == 1 && other.GetContact(0).point.y < GetCollider().transform.position.y) {
            if (state == State.JUMP) {
                SetState(State.GROUNDED);
                playerHorizontalControl.SetRunJumping(false);
                // Debug.Log("On Ground");
            }
        }
    }

    public bool IsGrounded()
    {
        Collider col = GetCollider();
        
        // Ray from the center of the collider down
        Ray ray = new Ray(col.bounds.center, Vector3.down);

        // A bit smaller than the actual radius so it doesn't catch on walls
        float radius = col.bounds.extents.x - .05f;

        // A bit below the bottom
        float fullDistance = col.bounds.extents.y + .05f;
        RaycastHit hit = new RaycastHit();
        
        if (Physics.SphereCast(ray, radius, out hit, fullDistance) && hit.transform.gameObject.tag == "Wall") {
            if (hit.point.y < col.transform.position.y) {
                return true;
            }
        }
        return false;
    }

    private bool CanStand() {
        Collider col = GetCollider();
        
        // Ray from the center of the collider up
        Ray ray = new Ray(col.bounds.center, Vector3.up);

        // From morph ball center to top of Samus' head
        float fullDistance = col.bounds.extents.y + .05f + 0.9f; // 0.9f is the difference from the inspector
        RaycastHit hit = new RaycastHit();
        if (Physics.Raycast(ray, out hit, fullDistance) && hit.transform.gameObject.tag == "Wall") {
            return false;
        }
        return true;
    }

    public enum State {
        GROUNDED, MORPHBALL, JUMP
    }
}
