﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChooseJumpingSprite : MonoBehaviour
{
    public GameObject standingJump;
    public GameObject runningJump;
    public GameObject shootJump;

    private PlayerHorizontalControl playerHorizontalControl;
    private bool shooting = false;

    void Start() {
        playerHorizontalControl = this.GetComponentInParent<PlayerHorizontalControl>();
    }

    void OnEnable() {
        standingJump.SetActive(true);
        runningJump.SetActive(false);
        shootJump.SetActive(false);
        shooting = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Z) || Input.GetKeyDown(KeyCode.Period)) {
            shooting = true;
        }

        if (shooting) {
            standingJump.SetActive(false);
            runningJump.SetActive(false);
            shootJump.SetActive(true);
        }
        else if (playerHorizontalControl.IsRunJumping() == true) {
            standingJump.SetActive(false);
            runningJump.SetActive(true);
            shootJump.SetActive(false);
        }
        else {
            standingJump.SetActive(true);
            runningJump.SetActive(false);
            shootJump.SetActive(false);
        }
    }
}
