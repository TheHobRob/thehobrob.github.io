﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerWallCollision : MonoBehaviour
{
    PlayerDirection playerDirection;
    PlayerState playerState;

    public float distanceFromWall = 0.1f;

    void Awake() 
    {
        playerDirection = this.GetComponent<PlayerDirection>();
        playerState = this.GetComponent<PlayerState>();
    }

    public bool IsFacingWall()
    {
        // This might cause issues with speed since GetComponent is expensive. 
        Collider col = playerState.GetCollider();

        Vector3 direction = playerDirection.IsFacingRight() ? Vector3.right : Vector3.left;
        Ray ray = new Ray(col.bounds.center, direction);

        // A little in front of samus
        float maxDistance = col.bounds.extents.x + distanceFromWall;

        RaycastHit hit = new RaycastHit();

        if (Physics.Raycast(ray, out hit, maxDistance) && hit.transform.gameObject.tag == "Wall")
            return true;
        else
            return false;
    }
}
