﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerRunningAnimation : MonoBehaviour
{
    public SpriteRenderer spriteRenderer;
    public Sprite forward1;
    public Sprite forward2;
    public Sprite forward3;
    private Sprite[] forwardAnimation; 

    public Sprite lookingUp1;
    public Sprite lookingUp2;
    public Sprite lookingUp3;
    private Sprite[] lookingUpAnimation; 

    bool lookingUp = false;
    int i = 0;
    private Sprite[] input;

    void OnEnable() {
        forwardAnimation = new Sprite[] {forward1, forward2, forward3};
        lookingUpAnimation = new Sprite[] {lookingUp1, lookingUp2, lookingUp3};
        i = 0;
        input = forwardAnimation;
        StartCoroutine(AnimateRunning());
    }

    // Update is called once per frame
    void Update()
    {
        bool holdingUp = (Input.GetKey(KeyCode.UpArrow));
        if (lookingUp && !holdingUp) {
            lookingUp = false;
            input = forwardAnimation;
        }
        else if (!lookingUp && holdingUp) {
            lookingUp = true;
            input = lookingUpAnimation;
        }
    }

    IEnumerator AnimateRunning() {
        while(true) {
            spriteRenderer.sprite = input[i % 3];
            i++;
            yield return new WaitForSeconds(0.05f);
        }
    }
}
