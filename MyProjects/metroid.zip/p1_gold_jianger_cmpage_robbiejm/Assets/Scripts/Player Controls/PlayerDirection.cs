﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerDirection : MonoBehaviour {

    private DirectionConfig directionConfig;
    
    bool facingRight = true;
    bool lookingUp = false;

    void Update() {
        // Horizontal
        directionConfig = this.GetComponentsInChildren<DirectionConfig>()[0];
        // Debug.Log(directionConfig);

        float horizontalAxis = Input.GetAxis("Horizontal");
        if (facingRight && horizontalAxis < 0) {
            facingRight = false;
            this.transform.localScale = new Vector3(-1, 1 ,1);
        }
        else if (!facingRight && horizontalAxis > 0) {
            facingRight = true;
            this.transform.localScale = new Vector3(1, 1, 1);
        }

        // Vertical
        // This only sets it once a key is pressed. Otherwise, if there is animation, the animation code will play.
        bool holdingUp = (Input.GetKey(KeyCode.UpArrow));
        if (lookingUp && !holdingUp) {
            lookingUp = false;
            directionConfig.spriteRenderer.sprite = directionConfig.spriteLookingForward;
        }
        else if (!lookingUp && holdingUp) {
            lookingUp = true;
            directionConfig.spriteRenderer.sprite = directionConfig.spriteLookingUpward;
        } 
    
        // Just a double check for correct sprite. Fixes player direction issues that arise from disabling modes. 
        if (!lookingUp && directionConfig.spriteRenderer.sprite == directionConfig.spriteLookingUpward) {
            directionConfig.spriteRenderer.sprite = directionConfig.spriteLookingForward;
        }
        else if (lookingUp && directionConfig.spriteRenderer.sprite == directionConfig.spriteLookingForward) {
            directionConfig.spriteRenderer.sprite = directionConfig.spriteLookingUpward;
        }
    }

    public bool IsFacingRight() {
        return facingRight;
    }

    public bool IsLookingUp() {
        return lookingUp;
    }
}
