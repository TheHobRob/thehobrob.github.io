﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChooseGroundedSprite : MonoBehaviour
{
    public GameObject standing;
    public GameObject running;
    
    private PlayerHorizontalControl playerHorizontalControl;

    void Start()
    {
        playerHorizontalControl = this.GetComponentInParent<PlayerHorizontalControl>();
    }

    void OnEnable() {
        standing.SetActive(true);
        running.SetActive(false);
    }

    void Update()
    {
        if (Input.GetAxis("Horizontal") != 0) {
            standing.SetActive(false);
            running.SetActive(true);
        } else {
            standing.SetActive(true);
            running.SetActive(false);
        }
    }
}
