﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerHorizontalControl : MonoBehaviour
{
    Rigidbody rigid;
    PlayerWallCollision playerWallCollision;
    PlayerInventory playerInventory;

    public float moveSpeed = 5;

    public bool isRunJumping = false;
    public bool playerControlling = true;
    float previousVelocityX = 0;

    void Awake() {
        rigid = this.GetComponent<Rigidbody>();
        playerWallCollision = this.GetComponent<PlayerWallCollision>();
        playerInventory = this.GetComponent<PlayerInventory>();
    }

    void Update() {
        // if (playerInventory.HasHomingMissile() && )
        //     return;

        Vector3 newVelocity = rigid.velocity;

        // Horizontal
        if (playerWallCollision.IsFacingWall()) {
            newVelocity.x = 0;
        }
        else if (isRunJumping && (Input.GetAxis("Horizontal") == 0)) {
            newVelocity.x = previousVelocityX;
        }
        else if (playerControlling) {
            newVelocity.x = Input.GetAxis("Horizontal") * moveSpeed;
            previousVelocityX = newVelocity.x;
        }

        rigid.velocity = newVelocity;
        // Debug.Log(Input.GetAxis("Horizontal"));
    }

    public void SetRunJumping(bool isRunJumping)
    {
        this.isRunJumping = isRunJumping;
    }

    public bool IsRunJumping() {
        return this.isRunJumping;
    }

    public void SetPlayerControlling(bool playerControlling) {
        this.playerControlling = playerControlling;
    }
}
