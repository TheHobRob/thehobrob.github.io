﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInventory : MonoBehaviour
{
    public bool hasMorphBall = false;
    public bool hasLongBeam = false;
    public bool hasMissile = false;
    public bool hasHomingMissile = false;
    public int numMissiles = 0;

    PlayerHealth playerHealth;

    void Awake() {
        playerHealth = this.GetComponent<PlayerHealth>();
    }

    public void OnTriggerEnter(Collider other)
    {
        // Debug.Log("Checking item collision...");
        if (other.tag == "MorphBall") {
            // Debug.Log("Touched morph ball");
            hasMorphBall = true;
        }
        else if (other.tag == "MissilePack") {
            // Debug.Log("Touched MissilePack");
            hasMissile = true;
            ChangeNumberOfMissile(10);
        } else if (other.tag == "LongBeamPack") {
            hasLongBeam = true;
        } else if (other.tag == "HomingMissilePack") {
            hasHomingMissile = true;
        }
    }

    public bool HasMorphBall() {
        return hasMorphBall || GameManager.isGodMode;
    }

    public bool HasLongBeam() {
        return hasLongBeam || GameManager.isGodMode;
    }

    public bool HasMissile() {
        return hasMissile;
    }

    public int MissileCount() {
        return numMissiles;
    }

    public bool HasHomingMissile() {
        return hasHomingMissile;
    }

    public void ChangeNumberOfMissile(int deltaMissiles) {
        numMissiles += deltaMissiles;
    }
}
