﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerHitBox : MonoBehaviour
{
    private HasHealth health;
    private Rigidbody rigidbody;
    public float knockbackAmount = 10f;
    
    DisableControlsOnTouch disableControlsOnTouch;

    void Start()
    {
        // health = this.GetComponent<PlayerHealth>();
        health = this.GetComponent<HasHealth>();
        rigidbody = this.GetComponent<Rigidbody>();
        disableControlsOnTouch = this.GetComponent<DisableControlsOnTouch>();
    }

    // OKAY. For some reason, we do not need to "PassUpTriggerEnterToInventory". OnTrigger calls here.
    public void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.tag == "Enemy") {
            StartCoroutine(disableControlsOnTouch.DisablePlayerControl());
            rigidbody.velocity = GetKnockback(other.GetContact(0).normal);
            // Debug.Log("Apply knockback");
        }
    }

    private Vector3 GetKnockback(Vector3 normal) {
        // Make Samus glow red
        
        // Push Samus opposite the direction she was hit
        Vector3 knockback = Vector3.zero;
        if (normal.x >= 1) {
            // enemy touched you on the left
            knockback = new Vector3(1f, 0f, 0);
        } else if (normal.x <= -1) {
            // enemy touched you on the right
            knockback = new Vector3(-1f, 0f, 0);
        } else {
            if (normal.y >= 1) {
                // enemy touched you from below
                knockback = Vector3.up;
            } else if (normal.y <= -1) {
                // enemy touched you from above
                knockback = Vector3.down;
            }
        }
        knockback *= knockbackAmount;

        return knockback;
    }
}
