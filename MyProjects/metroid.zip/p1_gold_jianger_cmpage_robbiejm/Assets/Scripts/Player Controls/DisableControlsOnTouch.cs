﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DisableControlsOnTouch : MonoBehaviour
{
    public float disableControlSeconds = 0.15f;

    public IEnumerator DisablePlayerControl(float seconds = 0.15f) {
        PlayerHorizontalControl playerHorizontalControl = GetComponent<PlayerHorizontalControl>();
        playerHorizontalControl.SetPlayerControlling(false);
        yield return new WaitForSeconds(seconds);
        playerHorizontalControl.SetPlayerControlling(true);
    }
}
