﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayMusicAndDestoryOnTriggerEnter : MonoBehaviour
{
    public AudioClip music;
    private AudioClip originalMusic;

    AudioSource source;

    void OnTriggerEnter(Collider collider) {
        source = Camera.main.GetComponent<AudioSource>();
        originalMusic = source.clip;

        StartCoroutine(PauseGameAndPlayMusic());
    }

    IEnumerator PauseGameAndPlayMusic() {
        source.clip = music;
        source.Play();

        Debug.Log("Before pause");
        // Time.timeScale = 0;
        yield return new WaitForSeconds(5f);
        // Time.timeScale = 1;
        Debug.Log("After pause");
        source.clip = originalMusic;
        source.Play();

        Destroy(this.gameObject);
    }
}
