﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChangeMusicOnTriggerEnter : MonoBehaviour
{
    public AudioClip music;

    private void OnTriggerEnter(Collider collider) {
        if (collider.tag != "Player") return;
        
        AudioSource source = Camera.main.GetComponent<AudioSource>();
        source.Stop();
        source.clip = music;
        source.Play();
    }
}
