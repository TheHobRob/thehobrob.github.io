﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChangeMusicOnTriggerExit : MonoBehaviour
{
    public AudioClip music;

    void OnTriggerExit(Collider collider) {
        if (collider.tag != "Player") return;
        
        AudioSource source = Camera.main.GetComponent<AudioSource>();
        source.Stop();
        source.clip = music;
        source.Play();
    }
}
