using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayMusicThenDestroyOnTriggerEnter : MonoBehaviour
{
    public AudioClip music;
    private AudioClip originalMusic;

    AudioSource source;

    void OnTriggerEnter(Collider collider) {
        if (collider.tag != "Player") return;
        
        source = Camera.main.GetComponent<AudioSource>();
        originalMusic = source.clip;

        StartCoroutine(PauseGameAndPlayMusic());
    }

    IEnumerator PauseGameAndPlayMusic() {
        source.clip = music;
        source.Play();

        Time.timeScale = 0;
        float pauseEndTime = Time.realtimeSinceStartup + 5;
        while (Time.realtimeSinceStartup < pauseEndTime)
        {
            yield return 0;
        }
        Time.timeScale = 1;

        source.clip = originalMusic;
        source.Play();

        Destroy(this.gameObject);
    }
}
