﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LavaScript : MonoBehaviour
{
    public float lavaForce = 10f;
    void OnTriggerStay(Collider other) {
        if(other.tag == "Player") {
            other.attachedRigidbody.AddForce(Vector3.down*lavaForce);
            // rb.velocity = new Vector3(rb.velocity.x, rb.velocity.y - .1f, rb.velocity.z);
            HasHealth ha = other.GetComponentInParent<HasHealth>();
            ha.AlterHealth(-1);
        }
    }
    
}
