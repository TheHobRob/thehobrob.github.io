﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour
{
    public int damageAmount = 7; // the amount of damage this enemy causes

    public int GetDamage() {
        return damageAmount;
    }
}
