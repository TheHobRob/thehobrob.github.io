﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerHealth : MonoBehaviour
{
    // Samus starts with 30 health
    // Zoomers take 3 hits before dying
    public int initialHealth = 30;
    public float IFrameDeltaTime;
    public float IFrameDurationSeconds;

    public SpriteRenderer spriteRenderer;

    private int currentHealth;
    private bool isInvincible = false;
    private PlayerHorizontalControl playerRun;

    void Start()
    {
        ResetHealth();
        spriteRenderer = this.GetComponentInChildren<SpriteRenderer>();
        playerRun = this.GetComponent<PlayerHorizontalControl>();
    }

    void Update()
    {

    }

    // used for healing and taking damage
    public void GainHealth(int health) {
        this.currentHealth += health;

        // health capacity is 99 (from the official game)
        if (this.currentHealth > 99) {
            this.currentHealth = 99;
        }
    }

    public void TakeDamage(int damage) {
        if (GameManager.isGodMode == true || isInvincible) return;
        
        this.currentHealth -= damage;

        StartCoroutine(DisablePlayerControl(0.15f));
        StartCoroutine(BecomeTemporarilyInvincible());
    }

    public void ResetHealth() {
        currentHealth = initialHealth;
    }

    public int GetHealth() {
        return currentHealth;
    }

    private IEnumerator BecomeTemporarilyInvincible()
    {
        isInvincible = true;
        Color original = spriteRenderer.color;
        spriteRenderer.color = Color.red;
        for (float i = 0; i < IFrameDurationSeconds; i += IFrameDeltaTime)
        {
            yield return new WaitForSeconds(IFrameDeltaTime);
        }
        isInvincible = false;
        spriteRenderer.color = original;
    }
    
    private IEnumerator DisablePlayerControl(float seconds) {
        playerRun.SetPlayerControlling(false);
        yield return new WaitForSeconds(seconds);
        playerRun.SetPlayerControlling(true);
    }
}
