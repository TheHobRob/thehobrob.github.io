﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHealth : MonoBehaviour
{
    // Samus starts with 30 health
    // Zoomers take 3 hits before dying
    public int initialHealth = 3;
    public SpriteRenderer spriteRenderer;

    private int currentHealth;

    void Start()
    {
        ResetHealth();
        spriteRenderer = this.GetComponent<SpriteRenderer>();
    }

    void Update()
    {

    }

    // used for healing and taking damage
    public void GainHealth(int health) {
        this.currentHealth += health;

        // health capacity is 99 (from the official game)
        if (this.currentHealth > initialHealth) {
            this.currentHealth = initialHealth;
        }
    }

    public void TakeDamage(int damage) {
        this.currentHealth -= damage;

        if (currentHealth <= 0) {
            Destroy(this.gameObject);
            if (this.GetComponent<ItemDrop>() != null) {
                this.GetComponent<ItemDrop>().DropItem();
            }
        }

        StartCoroutine(ChangeSpriteToDamageColor());
    }

    public void ResetHealth() {
        currentHealth = initialHealth;
    }

    public int GetHealth() {
        return currentHealth;
    }

    private IEnumerator ChangeSpriteToDamageColor() {
        Color original = spriteRenderer.color;
        spriteRenderer.color = Color.red;
        yield return new WaitForSeconds(0.15f);
        spriteRenderer.color = original;
    }
}
