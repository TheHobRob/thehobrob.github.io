﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[DisallowMultipleComponent]
public class EnemyHitBox : MonoBehaviour
{
    private HasHealth health;
    private Rigidbody rigidbody;

    void Awake()
    {
        health = this.GetComponent<HasHealth>();
        rigidbody = this.GetComponent<Rigidbody>();
    }

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Bullet") {  
            // TODO: maybe customize this based on bullet strength?
            Debug.Log("Enemy shot! Deal 1 damage");
            health.AlterHealth(-1);
        }
    }
}
