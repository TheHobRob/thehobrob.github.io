﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[RequireComponent(typeof(Rigidbody), typeof(Collider), typeof(HasHealth))]
public class Skree_Control : MonoBehaviour
{
    Rigidbody rb;
    Collider collider;
    HasHealth health;
    Vector3 skree_direction = Vector3.down;
    private GameObject player;
    public GameObject skree_bullet;
    public float bullets_speed;
    public float move_speed;
    private bool player_passed = false;
    private Vector3 player_position;

    // Start is called before the first frame update
    void Start()
    {
        rb = this.GetComponent<Rigidbody>();
        collider = this.GetComponent<Collider>();
        health = this.GetComponent<HasHealth>();

        player = GameObject.Find("Player");
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        player_position = player.transform.position;

        if (player_passed || CheckIfHit("Player", 10f)) {
            player_passed = true;
        }

        bool hasHitWall = CheckIfHit("Wall", 0.05f);
        if (player_passed && !hasHitWall) {
            Descend();
            transform.Translate(skree_direction * move_speed * Time.deltaTime);
            //transform.position = Vector3.MoveTowards(transform.position, player_position, move_speed * Time.deltaTime);
        }

        if (hasHitWall) {
            StartCoroutine(Explode());
        }
    }

    bool CheckIfHit(string tag, float ray_length) {
        // Raycast will point DOWN
        Ray ray = new Ray(collider.bounds.center, -transform.up);

        // Add the desired length to it
        float ray_distance = collider.bounds.extents.y + ray_length;

        // Check if the desired gameObject was hit
        RaycastHit hit = new RaycastHit();
        if (Physics.Raycast(ray, out hit, ray_distance) && hit.transform.gameObject.tag == tag) {
            return true;
        } else {
            return false;
        }
    }

    void Descend() {
        // Skree is going to go down always
        Vector3 target = Vector3.down;

        // Find what position the player is
        target.x = player_position.x - this.transform.position.x;

        // Set the direction of the skree to the target
        skree_direction = target;
    }

    IEnumerator Explode() {
        yield return new WaitForSeconds(2f);

        // Release projectiles
        // Debug.Log("I explodeed");

        // Right here the pre-explosion animation should play

        // Bullets clash with each other and all of them have different directions
        // this will work but it's v uglee
        Vector3[] bullet_directions = {
            Vector3.left, 
            Vector3.right, 
            (Vector3.up + Vector3.left).normalized, 
            (Vector3.up + Vector3.right).normalized
        };
        Vector3 center = this.transform.position;
        float offset = 0.2f;
        Vector3[] bullet_positions = {
            new Vector3(center.x - offset, center.y, center.z),
            new Vector3(center.x + offset, center.y, center.z),
            new Vector3(center.x - offset, center.y + offset, center.z),
            new Vector3(center.x + offset, center.y + offset, center.z)
        };

        for (int i = 0; i < 4; ++i) {
            GameObject bullet_instance = GameObject.Instantiate(skree_bullet, bullet_positions[i], Quaternion.identity);
            bullet_instance.GetComponent<Rigidbody>().velocity = (bullet_directions[i] * bullets_speed);
            //Debug.Log("Bullet made in location: " + bullet_positions[i] + " with speed " + bullet_directions[i]);
        }

        // Maybe switch to an explosion sprite then destroy
        Destroy(this.gameObject);
    }
}
