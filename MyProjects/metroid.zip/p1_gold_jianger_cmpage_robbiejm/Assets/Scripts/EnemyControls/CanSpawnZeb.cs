﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(SpriteRenderer))]
public class CanSpawnZeb : MonoBehaviour
{
    public GameObject zebPrefab;
    public float spawn_rate = 3.0f;
    public float detection_dist = 4.0f;
    public bool spawnZeb = false;
    private GameObject player;
    private float player_pos_x;
    private Vector3 position;
    private SpriteRenderer sprite;

    void Start()
    {
        player = GameObject.Find("Player");
        position = this.transform.position;
        sprite = this.GetComponent<SpriteRenderer>();

        StartCoroutine(SpawnZebs());
    }
    void Update()
    {
        // Update it so when the player is near, it starts spawning zebs
        player_pos_x = player.transform.position.x;
        spawnZeb = CheckIfPlayerIsNear();
    }

    bool CheckIfPlayerIsNear() {
        return (Mathf.Abs(player_pos_x - this.transform.position.x) < detection_dist);
    }

    void SummonZeb() {
        Vector3 zebDirection;
        float x_dir = 1f;
        if (player_pos_x <= position.x) {
            // player is in the left of the spawner
            zebDirection = Vector3.left;
            x_dir = 1f;
            
        } else {
            // player is in the right of the spawner
            zebDirection = Vector3.right;
            x_dir = -1f;
        }
        GameObject temp = GameObject.Instantiate(zebPrefab, this.transform.position, Quaternion.Euler(zebDirection));
        temp.transform.localScale = new Vector3(x_dir, 1, 1);
        temp.GetComponent<Zeb_Control>().SetDirection(zebDirection);
    }

    IEnumerator SpawnZebs() {
        yield return new WaitForSeconds(1.0f);

        while (true) {
            if (spawnZeb) {
                SummonZeb();
            }
            yield return new WaitForSeconds(spawn_rate);
        }
    }
}
