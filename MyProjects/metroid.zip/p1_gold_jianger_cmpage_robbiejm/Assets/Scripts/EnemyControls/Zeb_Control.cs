﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody), typeof(Collider), typeof(HasHealth))]
public class Zeb_Control : MonoBehaviour
{
    private Rigidbody rigidbody;
    private Collider collider;
    private HasHealth health;
    private GameObject player;

    private Vector3 direction;
    private Vector3 target;
    private bool player_spotted = false;
    public float rise_speed = 3f;
    public float zoom_speed = 3f;

    void Start() {
        rigidbody = this.GetComponent<Rigidbody>();
        collider = this.GetComponent<Collider>();
        health = this.GetComponent<HasHealth>();

        player = GameObject.Find("Player");
        Ascend();

        // The Zeb need to be destroyed to not cause lag :(
        StartCoroutine(TimedDeath());
    }

    void Update() {
        target = player.transform.position;
        FoundPlayer();
        if (!player_spotted) {
            Ascend();
        } else {
            Zoom();
        }
    }

    void Ascend() {
        this.transform.Translate(Vector3.up * rise_speed * Time.deltaTime);
    }

    void Zoom() {
        this.transform.Translate(direction * zoom_speed * Time.deltaTime);
    }

    void FoundPlayer() {
        if (this.transform.position.y >= target.y) {
            player_spotted = true;
        }
        return;
    }

    public void SetDirection(Vector3 direction) {
        this.direction = direction;
    }

    IEnumerator TimedDeath() {
        yield return new WaitForSeconds(15.0f);
        Destroy(this.gameObject);
    }
}
