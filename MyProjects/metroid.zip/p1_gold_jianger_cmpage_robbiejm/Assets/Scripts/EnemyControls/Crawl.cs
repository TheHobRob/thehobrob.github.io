﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Crawl : MonoBehaviour
{
    public float moveSpeed = 0.005f;
    public float rotateSpeed = 1f;
    public Vector3 initialTranslation = Vector3.left;

    public float halfWidth;
    public float halfHeight;
    private int currentRotation;

    Rigidbody rigid;
    Collider col;
    OnSurface isOnSurface;

    // Start is called before the first frame update
    void Start()
    {
        rigid = this.GetComponent<Rigidbody>();
        col = this.GetComponent<Collider>();
        isOnSurface = this.GetComponent<OnSurface>();
        currentRotation = (int)this.transform.rotation.z;

        halfWidth = col.bounds.extents.x;
        halfHeight = col.bounds.extents.y;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        bool onSurface = isOnSurface.IsOnSurface();

        // Rotate when we run out of tile
        if (!onSurface) {
            //Debug.Log("Not on surface");
            RotateCounterClockwise();
        } 
        else if (onSurface && HitWall()) {
            RotateClockwise();
        }
        else {
            //Debug.Log("Grounded!");
            // transform.Translate(initialTranslation * moveSpeed);
        }
        transform.Translate(initialTranslation * moveSpeed);
    }

    bool HitWall() {
        Ray ray = new Ray(col.bounds.center, -transform.right); // Vector to the left

        // A bit to the left
        float fullDistance = col.bounds.extents.x + .05f;
        // Debug.Log("Enemy bounds:" + col.bounds.extents.ToString());

        RaycastHit hit = new RaycastHit();
        if (Physics.Raycast(ray, out hit, fullDistance) && 
            (hit.transform.gameObject.tag == "Wall" || hit.transform.gameObject.tag == "MissileDoor"))
            return true;
        else
            return false;
    }

    void RotateClockwise() {
        // Debug.Log("Rotate CW");
        this.transform.Rotate(Vector3.back * 90);
    }

    void RotateCounterClockwise() {
        // Rotate first
        // Debug.Log("Rotate CCW");

        // Then fix the offset (this only works 1/4 times like this)
        // set the player position to its new location 
        this.transform.position = GetOffset(this.transform.up, this.transform.position);
        this.transform.Rotate(Vector3.forward * 90);
    }

    Vector3 GetOffset(Vector3 playerUpAxis, Vector3 currentLocation) {
        Vector3 offset = currentLocation;

        if (playerUpAxis == Vector3.left && initialTranslation == Vector3.left) {
            offset.x += halfHeight + 0.05f;
            offset.y -= halfHeight;
        }
        else if (playerUpAxis == Vector3.down) {
            offset.x += halfHeight + 0.05f;
            offset.y += halfHeight + 0.05f;
        }
        else if (playerUpAxis == Vector3.right) {
            offset.x -= halfHeight + 0.05f;
            offset.y += halfHeight;
        }
        else if (playerUpAxis == Vector3.up) {
            offset.x -= halfHeight;
            offset.y -= halfHeight + 0.05f;
        }

        return offset;
    }
}
