﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RipperMovement : MonoBehaviour
{
    public float initialDirection = -1;
    public float speed = 0.005f;

    Rigidbody rigidbody;
    Collider col;
    Vector3 movement;

    void Awake() {
        rigidbody = this.GetComponent<Rigidbody>();
        col = this.GetComponent<Collider>();
        movement = Vector3.right * initialDirection;
    }

    // Update is called once per frame
    void Update()
    {
        // Send raycast to left and right. Whcihever one hits, we'll reverse the direction of the ripper.
        
        Ray leftRay = new Ray(col.bounds.center, -transform.right);
        Ray rightRay = new Ray(col.bounds.center, transform.right);
        float maxDistance = col.bounds.extents.x + 0.05f;

        RaycastHit hit = new RaycastHit();

        if (Physics.Raycast(leftRay, out hit, maxDistance) && hit.transform.gameObject.tag == "Wall") {
            movement = Vector3.right;
        } else if (Physics.Raycast(rightRay, out hit, maxDistance) && hit.transform.gameObject.tag == "Wall") {
            movement = Vector3.left * speed;
        }
        transform.Translate(movement * Time.deltaTime);
    }
}
