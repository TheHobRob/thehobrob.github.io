﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class Reo_Control : MonoBehaviour
{
    Rigidbody rigidbody;
    Collider collider;
    public float fly_speed = 7.0f;
    public float x_movement = 0.3f;
    public float pause_time = 0.75f;
    
    private bool descending = true;
    private bool facingLeft = false;
    private bool stopped = false;
    private bool fly_low = false;
    private Vector3 target;
    private GameObject player;

    void Start()
    {
        rigidbody = this.GetComponent<Rigidbody>();
        collider = this.GetComponent<Collider>();
        
        player = GameObject.Find("Player");
    }

    void Update()
    {
        // check if Reo is in descending state AND not stopped AND not flying low
        if (descending && !stopped && !fly_low) {
            Descend();
            if (CheckIfHit("Player", 5f, "left") || CheckIfHit("Player", 5f, "right")) {
                fly_low = true;
            }
        } 
        // check if Reo is not in descending state AND not stopped AND not flying low
        else if (!descending && !stopped && !fly_low) {
            Ascend();
        } 
        // check if Reo is flying low
        else if (fly_low) {
            FlyLow();
        }

        // stop descending if the floor is near
        if (CheckIfHit("Wall", 1f, "down")) {
            descending = false;
        }
        // stop ascending if Reo hit the ceiling
        else if (CheckIfHit("Wall", 0.05f, "up")){
            descending = true;
            StartCoroutine(Pause());
        }

        // flip the Reo direction if there is a wall to the left or right
        if (CheckIfHit("Wall", 0.05f, "right")) {
            facingLeft = true;
        }
        else if (CheckIfHit("Wall", 0.05f, "left")) {
            facingLeft = false;
        }

        if (fly_low && Input.GetKeyDown(KeyCode.X)) {
            fly_low = false;
            descending = false;
        }
    }

    void Descend() {
        if (facingLeft) {
            this.transform.Translate((new Vector3(-1 * x_movement, -1f, 0f)) * fly_speed * Time.deltaTime);
        } else {
            this.transform.Translate((new Vector3(x_movement, -1f, 0)) * fly_speed * Time.deltaTime);
        }
    }

    void Ascend() {
        if (facingLeft) {
            this.transform.Translate((new Vector3(-1 * x_movement, 1f, 0f)) * fly_speed * Time.deltaTime);
        } else {
            this.transform.Translate((new Vector3(x_movement, 1f, 0f)) * fly_speed * Time.deltaTime);
        }
    }

    void FlyLow() {
        Vector3 tra;
        if (facingLeft) {
            tra = Vector3.left;
        } else {
            tra = Vector3.right;
        }

        if (!CheckIfHit("Wall", 0.05f, "down")) {
            tra += Vector3.down;
        }

        this.transform.Translate(tra * 0.5f * fly_speed * Time.deltaTime);
    }

    bool CheckIfHit(string tag, float ray_length, string direction) {
        Vector3 dir;
        float extents;
        if (direction == "up") {
            dir = transform.up;
            extents = collider.bounds.extents.y;
        } else if (direction == "down") {
            dir = -transform.up;
            extents = collider.bounds.extents.y;
        } else if (direction == "right") {
            dir = transform.right;
            extents = collider.bounds.extents.x;
        } else if (direction == "left") {
            dir = -transform.right;
            extents = collider.bounds.extents.x;
        } else {
            return false;
        }

        // Raycast will point Down or Up
        Ray ray = new Ray(collider.bounds.center, dir);

        // Add the desired length to it
        float ray_distance = extents + ray_length;

        // Check if the desired gameObject was hit
        RaycastHit hit = new RaycastHit();
        if (Physics.Raycast(ray, out hit, ray_distance) && hit.transform.gameObject.tag == tag) {
            return true;
        } else {
            return false;
        }
    }

    void CheckPlayerLocation() {
        // maybe ignore this if the player is not near the Reo
        target = player.transform.position;

        if (Mathf.Abs(target.x - this.transform.position.x) < 7.0f) {
            facingLeft = (target.x < this.transform.position.x);
        }
    }

    IEnumerator Pause() {
        stopped = true;
        CheckPlayerLocation();
        yield return new WaitForSeconds(pause_time);
        stopped = false;
    }
}
