﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AlternateSprites : MonoBehaviour
{
    public SpriteRenderer spriteRenderer;

    public Sprite sprite1;
    public Sprite sprite2;

    private bool isSprite1 = true;

    void Start() {
        spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
    }

    void OnEnable() {
        StartCoroutine(ChangeSprites());
    }

    IEnumerator ChangeSprites() {
        while(true) {
            yield return new WaitForSeconds(0.1f);
            if (isSprite1 == true) {
                spriteRenderer.sprite = sprite2;
                isSprite1 = false;
            } else {
                spriteRenderer.sprite = sprite1;
                isSprite1 = true;
            }
        }
    }
}
