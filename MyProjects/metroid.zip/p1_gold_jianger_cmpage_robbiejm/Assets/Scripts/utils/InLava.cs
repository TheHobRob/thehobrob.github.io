﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InLava : MonoBehaviour
{
    // Start is called before the first frame update
    private bool inLava = false;
    void OnTriggerStay(Collider other) {
        if (other.tag == "Lava") {
            inLava = true;
        }
    }

    void OnTriggerExit(Collider other) {
        if (other.tag == "Lava") {
            inLava = false;
        }
    }

    public bool GetInLava() {
        return inLava;
    }
}
