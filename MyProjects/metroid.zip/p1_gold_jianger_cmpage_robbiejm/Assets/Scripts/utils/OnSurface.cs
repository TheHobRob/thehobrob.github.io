﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OnSurface : MonoBehaviour
{
    Collider col;

    void Start()
    {
        col = this.GetComponent<Collider>();
    }
    
    public bool IsOnSurface() {
        Ray ray = new Ray(col.bounds.center, -transform.up);

        // A bit below the bottom
        float fullDistance = col.bounds.extents.y + .05f;
        // Debug.Log("Enemy bounds:" + col.bounds.extents.ToString());

        RaycastHit hit = new RaycastHit();
        if (Physics.Raycast(ray, out hit, fullDistance) && (hit.transform.gameObject.tag == "Wall" || hit.transform.gameObject.tag == "MissileDoor"))
            return true;
        else
            return false;
    }
}
