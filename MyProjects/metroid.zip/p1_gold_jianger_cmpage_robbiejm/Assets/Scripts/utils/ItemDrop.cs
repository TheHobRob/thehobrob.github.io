﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(HasHealth))]
public class ItemDrop : MonoBehaviour
{
    public GameObject dropItem;
    public GameObject missileDrop;
    public float dropChance;

    private GameObject[] items;
    private int itemNum;
    private int randomNum;
    private HasHealth healthComponent;
    private GameObject player;
    private PlayerInventory playerInventory;

    private void Start()
    {
        healthComponent = GetComponent<HasHealth>();
        items = new GameObject[] {dropItem, missileDrop};
        player = GameObject.FindWithTag("Player");
        playerInventory = player.GetComponent<PlayerInventory>();
    }

    public void DropItem() {
        if (playerInventory.HasMissile()) {
            itemNum = Random.Range(0, 2);
        } else {
            itemNum = 0;
        }

        // Let's just say out of 100 times
        randomNum = Random.Range(0, 101);

        // 10% chance drops
        if (randomNum <= dropChance * 100) {
            Instantiate(items[itemNum], this.transform.position, Quaternion.identity);
            // Debug.Log("Dropped a health pack");
        }
    }
}
