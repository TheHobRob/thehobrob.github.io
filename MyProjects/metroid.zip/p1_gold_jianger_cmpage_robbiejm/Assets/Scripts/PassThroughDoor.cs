﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PassThroughDoor : MonoBehaviour
{
    // Start is called before the first frame updates
    public Transform player;
    public GameObject leftDoor;
    public GameObject rightDoor;

    public float transitionDuration = .6f;
    private bool intransition = false;

    Collider col;

    void Awake() {
        col = this.GetComponent<Collider>();
    }

    void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.tag == "Player"){
            // if left door got deactived
            if(leftDoor.activeSelf == false && intransition == false) {
                intransition = true;
                Vector3 newPos = new Vector3(player.transform.position.x + 3.5f, player.transform.position.y, player.transform.position.z);
                StartCoroutine(Transition(player.transform.position, newPos, false));
            } else if (rightDoor.activeSelf == false && intransition == false) {
                intransition = true;
                Vector3 newPos = new Vector3(player.transform.position.x - 3.5f, player.transform.position.y, player.transform.position.z);
                StartCoroutine(Transition(player.transform.position, newPos, true));
            }
        }
    }

    IEnumerator Transition(Vector3 start, Vector3 end, bool right) {
        float t = 0.0f;
        // going left to right
        if(!right) {
            rightDoor.SetActive(false);
            while (t < 1.0f) {
                t += Time.deltaTime * (Time.timeScale/transitionDuration);
                player.transform.position = Vector3.Lerp(start, end, t);
                yield return 0;
            }
            leftDoor.SetActive(true);
            rightDoor.SetActive(true);
            yield return 0;
        } else {
            leftDoor.SetActive(false);
            while (t < 1.0f) {
                t+= Time.deltaTime * (Time.timeScale/transitionDuration);
                player.transform.position = Vector3.Lerp(start, end, t);
                yield return 0;
            }
            leftDoor.SetActive(true);
            rightDoor.SetActive(true);
            yield return 0;
        }

        intransition = false;
    }
}
