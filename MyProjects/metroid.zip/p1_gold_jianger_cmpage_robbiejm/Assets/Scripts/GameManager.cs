﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public Text healthText;
    public Text MissileText; // Should not be active initially
    public GameObject player;
    public static bool isGodMode = false;

    private HasHealth playerHealth;
    private PlayerInventory playerInventory;

    private bool privateLevelAccessed = false;

    void Start()
    {
        playerHealth = player.GetComponent<HasHealth>();
        playerInventory = player.GetComponent<PlayerInventory>();
    }

    void Update()
    {        
        // If the player dies, just restart the scene
        if (playerHealth.GetHealth() <= 0) {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }

        if (Input.GetKeyDown(KeyCode.Alpha4)) {
            if (privateLevelAccessed == false) {
                privateLevelAccessed = true;
                SceneManager.LoadScene("Bonus Level");
            }
        }

        // Toggle invincible mode
        if (Input.GetKeyDown(KeyCode.Alpha1)) {
            isGodMode = !isGodMode;
        }

        healthText.text = "Health: " + playerHealth.GetHealth().ToString();
        if (isGodMode == true) {
            MissileText.text = "Missiles: Inf";
        } else {
            MissileText.text = "Missiles: " + playerInventory.MissileCount().ToString();
        }
    }
}
