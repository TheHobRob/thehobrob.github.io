﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HasHealth : MonoBehaviour
{
    public int initialHealth = 30;
    public bool colorChange = true;
    public int currentHealth;
    public bool isDoor = false;

    // Stuff we need to pull out specifically for player.
    public bool isInvincible = false;

    void Start()
    {
        ResetHealth();
    }

    // used for healing and taking damage
    private void GainHealth(int health) {
        this.currentHealth += health;

        // health capacity is 99 (from the official game)
        if (this.currentHealth > 99) {
            this.currentHealth = 99;
        }
    }

    private void TakeDamage(int damage) {
        if (isInvincible) {
            return;
        }

        if (GameManager.isGodMode == true && gameObject.tag == "Player") {
            return;
        }

        this.currentHealth += damage;
        // Debug.Log(currentHealth);

        EnableIFramesOnHit iframe = this.GetComponentInChildren<EnableIFramesOnHit>();
        if (iframe != null) {
            StartCoroutine(iframe.BecomeTemporarilyInvincible());
        } else {
            StartCoroutine(DoDamageAnimation()); // For enemies
        }

        if (currentHealth <= 0) {
            if (isDoor) {
                this.gameObject.SetActive(false);
            } else if (this.gameObject.tag != "Player") {
                Destroy(this.gameObject);
            }
            
            if (this.GetComponent<ItemDrop>() != null) {
                this.GetComponent<ItemDrop>().DropItem();
            }
        }
    }

    public void AlterHealth(int changeHealth) {
        if (changeHealth >= 0) {
            GainHealth(changeHealth);
        } else {
            TakeDamage(changeHealth);
        }
    }

    public void ResetHealth() {
        currentHealth = initialHealth;
    }

    public int GetHealth() {
        return currentHealth;
    }

    public void SetIsInvincible(bool isInvincible) {
        // Debug.Log("Set invincibility" + isInvincible.ToString());
        this.isInvincible = isInvincible;
    }

    private IEnumerator DoDamageAnimation() {
        SpriteRenderer sprite = GetComponent<SpriteRenderer>();
        if (sprite == null) yield break;
        if (!colorChange) yield break;
        Color original = sprite.color;
        sprite.color = Color.red;
        yield return new WaitForSeconds(0.15f);
        sprite.color = original;
    }

}
