﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[DisallowMultipleComponent]
[RequireComponent(typeof(Collider))]
public class AlterHealthOnTouch : MonoBehaviour
{
    // If we want to gain health, this value is negative.
    public int how_much_damage = 7;
    public float knockback_force_mag = 10f;

    void Start() {
    }

    void OnTriggerEnter(Collider other) {
        // Debug.Log("AlterHealthOnTouch! OnTrigger");
        HasHealth other_hp = other.GetComponent<HasHealth>();
        if (other_hp == null) {
            other_hp  = other.GetComponentInParent<HasHealth>();
        }
        if (other_hp == null)
            return;
        if (other.tag == "MissileDoor") {
            if(this.tag == "Missile") {
                other_hp.AlterHealth(-how_much_damage);
            }
        } else {
            other_hp.AlterHealth(-how_much_damage);
        }

        /* If we are gaining health, don't need to apply knockback. */
        if (how_much_damage <= 0) {
            Destroy(this.gameObject);
            return;
        }
    }

    void OnCollisionEnter(Collision other) {
        HasHealth other_hp = other.gameObject.GetComponent<HasHealth>();
        other_hp  = other.gameObject.GetComponentInChildren<HasHealth>();
        if (other_hp == null)
            return;
        
        // Debug.Log("AlterHealthOnTouch! On Collision.");
        other_hp.AlterHealth(-how_much_damage);


        /* THIS NEEDS TO BE FIXED. Doesn't work here, but works when you put it on a player hit box component.*/
        /* Knockback */
        // Rigidbody other_rb = other.rigidbody;
        // if (other_rb == null)
        //     return;

        // This is NOT working.
        // Vector3 knockback_force = ((other.gameObject.transform.position - this.gameObject.transform.position)
        //                             + Vector3.up * 3.0f).normalized * knockback_force_mag;
        // // other_rb.velocity = knockback_force;
        // other_rb.velocity = Vector3.up;
        // Debug.Log("Knockback force" + knockback_force.ToString());
    }
}
