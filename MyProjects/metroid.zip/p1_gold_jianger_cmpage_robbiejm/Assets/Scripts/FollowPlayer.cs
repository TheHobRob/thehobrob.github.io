﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class FollowPlayer : MonoBehaviour
{
    public Transform target;
    public float transitionDuration = .3f;
    public Transform Level;

    private Transform curr_room;
    private Transform next_room;
    private Transform prev_room;
    private int room_number = 0;
    // private bool inTransition = false;

    void Start() {
        if(SceneManager.GetActiveScene().name == "Bonus Level") {
            curr_room = Level.transform.GetChild(room_number);
            next_room = null;
            room_number = 0;
            return;
        }

        curr_room = Level.transform.GetChild(room_number);
        next_room = Level.transform.GetChild(room_number+1);
        prev_room = null;
    }
    void LateUpdate()
    {
        if(SceneManager.GetActiveScene().name == "Bonus Level") {
            if(room_number == 0) {
                if(11.0f <= target.transform.position.x && 13.0f >= target.transform.position.x) {
                    transform.position = new Vector3(target.transform.position.x, this.transform.position.y, this.transform.position.z);
                }
            }
            if(room_number == 1) {
                if(-3.0f >= target.transform.position.x && -1.0f <= target.transform.position.x ) {
                    transform.position = new Vector3(target.transform.position.x, this.transform.position.y, this.transform.position.z);
                }
            }
            // handle moving to room to right
            if (room_number == 0 && 4.0f >= target.transform.position.x) {
                room_number = 1;
                Vector3 end = new Vector3(target.transform.position.x - 7.5f, this.transform.position.y, this.transform.position.z);
                StartCoroutine(Transition(transform.position, end));
            } else
            // moving into room to left normal *140 f height tells us were moving into room 7 or 8
            if(5.0f <= target.transform.position.x && room_number == 1) {
                room_number = 0;
                Vector3 end = new Vector3(target.transform.position.x + 7.5f, this.transform.position.y, this.transform.position.z);
                StartCoroutine(Transition(transform.position, end));
            }
            if (room_number == 1 && -8.0f >= target.transform.position.x) {
                SceneManager.LoadScene("Main");
                curr_room = Level.transform.GetChild(room_number);
                next_room = Level.transform.GetChild(room_number+1);
                prev_room = null;
                room_number = 0;
            }
                
            return;
        }
        // update player position in vertical fashion for vertical rooms
        if(room_number == 3 || room_number == 5) {
            transform.position = new Vector3(this.transform.position.x, target.transform.position.y, this.transform.position.z);
        }


        // handle end of room

        // handle end of room for room 6
        if(next_room == null) {
          // 126 end of room 6
          if(room_number == 6) {
            if(118.5f + curr_room.transform.position.x >= target.transform.position.x && curr_room.transform.position.x + 7.5f <= target.transform.position.x) {
              transform.position = new Vector3(target.transform.position.x, this.transform.position.y, this.transform.position.z);
            }
          }
        // handle end of room for the rest of the rooms
        } else if(next_room.transform.position.x - 7.5f >= target.transform.position.x && curr_room.transform.position.x + 7.5f <= target.transform.position.x ) {
            transform.position = new Vector3(target.transform.position.x, this.transform.position.y, this.transform.position.z);
        }
        // handle moving into room to the right, this doesn't apply to room6
        if (next_room != null && next_room.transform.position.x <= target.transform.position.x) {
            // if(inTransition) return;
            // inTransition = true;
            if(room_number == 7) {
                prev_room = Level.transform.GetChild(7);
                room_number = 3;
            } else if(room_number == 8) {
                prev_room = Level.transform.GetChild(room_number);
                room_number--;
            } else {
                prev_room = Level.transform.GetChild(room_number);
                room_number++;
            }
            // room_number++;
            // transform.position = new Vector3(target.transform.position.x + 8f, this.transform.position.y, this.transform.position.z);
            Vector3 end = new Vector3(target.transform.position.x + 7.5f, this.transform.position.y, this.transform.position.z);
            StartCoroutine(Transition(transform.position, end));


            if(room_number < 6) {
                curr_room = Level.transform.GetChild(room_number);
                next_room = Level.transform.GetChild(room_number+1);
            }
            else if(room_number == 6) {
                curr_room = Level.transform.GetChild(room_number);
                next_room = null;
            } else if(room_number == 7) {
                curr_room = Level.transform.GetChild(room_number);
                next_room = Level.transform.GetChild(3);
            } else if(room_number == 8) {
                curr_room = Level.transform.GetChild(room_number);
                next_room = Level.transform.GetChild(7);
            }
        } else
        // moving into room to left normal *140 f height tells us were moving into room 7 or 8
        if(curr_room.transform.position.x >= target.transform.position.x && target.transform.position.y < 140f) {
            // if(inTransition) return;
            // inTransition = true;
            room_number--;
            Vector3 end = new Vector3(target.transform.position.x - 7.5f, this.transform.position.y, this.transform.position.z);
            StartCoroutine(Transition(transform.position, end));
            curr_room = Level.transform.GetChild(room_number);
            next_room = Level.transform.GetChild(room_number+1);
            
        } else
        // moving into room to left but high up, * different room and current room update behavior, no longer sequential
        if(target.transform.position.y >= 140f && curr_room.transform.position.x >= target.transform.position.x) {
            // if(inTransition) return;
            // inTransition = true;
            Debug.Log("Transitioning left on top floor");
            Debug.Log(target.transform.position.y);
            Vector3 end = new Vector3(target.transform.position.x - 7.5f, this.transform.position.y, this.transform.position.z);
            if (room_number == 3) {
              room_number = 7;
            //   next_room = Level.transform.GetChild(3);
              next_room = null;
              curr_room = Level.transform.GetChild(room_number);
            } else
            if (room_number == 7) {
              room_number = 8;
              next_room = Level.transform.GetChild(7);
              curr_room = Level.transform.GetChild(room_number);
            }
            StartCoroutine(Transition(transform.position, end));
        } else 
        if (next_room == null && room_number == 7) {
            next_room = Level.transform.GetChild(3);
        }
    }

    IEnumerator Transition(Vector3 start, Vector3 end) {
        float t = 0.0f;
        Debug.Log("In transition");
        while (t < 1.0f) {
            t+= Time.deltaTime * (Time.timeScale/transitionDuration);
            transform.position = Vector3.Lerp(start, end, t);
        }
        yield return 0;
        // inTransition = false;
        // yield return 0;
    }
}
