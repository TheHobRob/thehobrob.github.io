﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeativateOnMissile : MonoBehaviour
{
    private Collider col;
    public float knockbackAmount = 10f;

    void Awake()
    {
        col = this.GetComponent<Collider>();
    }

    public void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.tag == "Missile") {
            this.gameObject.SetActive(false);
        }
    }
}
