﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyOnTriggerEnter : MonoBehaviour
{
    public AudioClip clip; // Set this in inspector

    void OnTriggerEnter(Collider other)
    {
        if (clip != null) {
            Camera.main.GetComponent<AudioSource>().PlayOneShot(clip);
        }
        Destroy(this.gameObject);
    }
}
