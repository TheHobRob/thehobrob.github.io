﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyWhenOffCamera : MonoBehaviour
{
    Camera cam;

    // Start is called before the first frame update
    void Awake()
    {
        cam = Camera.main;
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 viewPos = cam.WorldToViewportPoint(transform.position);
        // Debug.Log("Camera pos: " + viewPos.ToString());
        if (viewPos.x < 0f || 1f < viewPos.x || viewPos.y < 0f || 1f < viewPos.y)
            Destroy(this.gameObject); 
    }
}
