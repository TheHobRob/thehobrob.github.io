﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zoomer_Control : MonoBehaviour
{
    private Rigidbody rigidbody;
    private Collider collider;

    public Vector3 init_direction;
    public float move_speed = 5f;
    public bool isOnSurface;
    public bool isFacingLeft;
    public bool wallOnRight;
    public bool wallOnLeft;
    public Vector3 rayCastOrigin;

    void Start()
    {
        rigidbody = this.GetComponent<Rigidbody>();
        collider = this.GetComponent<Collider>();

        isFacingLeft = (init_direction == Vector3.left);
    }

    void FixedUpdate()
    {
        UpdateRayCast();
        isOnSurface = IsOnSurface();
        wallOnRight = HitWall(transform.right);
        wallOnLeft = HitWall(-transform.right);

        if (!isOnSurface && !wallOnRight)
        {
            if (isFacingLeft)
                RotateCounterClockWise();
            else
                RotateClockwise();
        }
        else if (wallOnLeft && isFacingLeft)
        {
            RotateClockwise();
        }
        this.transform.Translate(init_direction * move_speed * Time.deltaTime);
    }

    void RotateClockwise()
    {
        this.transform.Rotate(Vector3.back * 90);
    }

    void RotateCounterClockWise()
    {
        this.transform.position = GetOffset(this.transform.up, this.transform.position);
        this.transform.Rotate(Vector3.forward * 90);
    }

    void UpdateRayCast()
    {
        Vector3 v = this.transform.up;
        if (isFacingLeft)
        {
            if (v == Vector3.up || v == Vector3.left)
                rayCastOrigin.x = collider.bounds.max.x;
            else if (v == Vector3.right || v == Vector3.down)
                rayCastOrigin.x = collider.bounds.min.x;
        }
        else
        {
            if (v == Vector3.up || v == Vector3.right)
                rayCastOrigin.x = collider.bounds.min.x;
            else if (v == Vector3.down || v == Vector3.left)
                rayCastOrigin.x = collider.bounds.max.x;
        }


        rayCastOrigin.y = collider.bounds.min.y;
    }

    bool HitWall(Vector3 direction)
    {
        Ray ray = new Ray(collider.bounds.center, direction);

        float distance = collider.bounds.extents.x + 0.05f;

        RaycastHit hit = new RaycastHit();
        if (Physics.Raycast(ray, out hit, distance) && hit.transform.gameObject.tag == "Wall")
            return true;
        else
            return false;
    }

    bool IsOnSurface()
    {
        Ray ray = new Ray(rayCastOrigin, -transform.up);

        float distance = 0.05f;

        RaycastHit hit = new RaycastHit();
        if (Physics.Raycast(ray, out hit, distance) && hit.transform.gameObject.tag == "Wall")
            return true;
        else
            return false;
    }

    Vector3 GetOffset(Vector3 playerUpAxis, Vector3 currentLocation)
    {
        Vector3 offset = currentLocation;
        float halfWidth = collider.bounds.extents.x;
        float halfHeight = collider.bounds.extents.y;
        float wiggle = 0.05f;

        if (playerUpAxis == Vector3.left && init_direction == Vector3.left)
        {
            offset.x += halfHeight + wiggle;
            offset.y -= halfHeight;
            Debug.Log("Offset: " + offset);
        }
        return offset;
    }
}
