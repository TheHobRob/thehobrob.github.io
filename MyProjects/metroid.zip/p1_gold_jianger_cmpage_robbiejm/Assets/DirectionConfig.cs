﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DirectionConfig : MonoBehaviour
{
    public SpriteRenderer spriteRenderer;

    public Sprite spriteLookingForward;
    public Sprite spriteLookingUpward;
}
