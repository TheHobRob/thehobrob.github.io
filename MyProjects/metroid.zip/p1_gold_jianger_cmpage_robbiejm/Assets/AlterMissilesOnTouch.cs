﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[DisallowMultipleComponent]
[RequireComponent(typeof(Collider))]
public class AlterMissilesOnTouch : MonoBehaviour
{
    void OnTriggerEnter(Collider other) {
        PlayerInventory inv = other.GetComponentInParent<PlayerInventory>();
        inv.ChangeNumberOfMissile(1);
        Destroy(this.gameObject);
    }
}
