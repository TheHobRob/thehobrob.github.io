﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponConfig : MonoBehaviour
{
    public SpriteRenderer spriteRenderer;
    public Sprite shootingForwardPrefab;
    public Sprite shootingUpwardPrefab;

    public Transform firingPositionForward;
    public Transform firingPositionUpward;
}
