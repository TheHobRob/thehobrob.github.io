﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(HasElementMaterial), typeof(HasElementInteractions))]
public class HasElement : MonoBehaviour
{
    private Element element;
    public Element.ElementType elementType;

    void Awake() {
        element = new Element(elementType);
    }

    public Element GetElement() {
        return element;
    }

    public void changeElement (Element.ElementType newElementType) {
        this.element = new Element(newElementType);
        GetComponent<HasElementMaterial>().LoadMaterial();
        GetComponent<HasElementInteractions>().LoadElement();
    }
}
