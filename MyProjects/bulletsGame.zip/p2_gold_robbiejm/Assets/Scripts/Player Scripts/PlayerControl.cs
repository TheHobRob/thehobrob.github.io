using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(PlayerRespawn), typeof(CanCheckGround))]
public class PlayerControl : MonoBehaviour {
    public float moveSpeed = 0.15f;
    public float rotationSpeed = 4f;
    public float jumpPower = 7f;
    public float fallMultiplier = 2.5f;
    public float lowJumpMultiplier = 2f;
    
    private Rigidbody rb;
    private CanCheckGround checkGround;
    void Start() {
        rb = this.GetComponent<Rigidbody>();
        checkGround = this.GetComponent<CanCheckGround>();
    }

    void Update() {
        if (rb.velocity.y < 0) {
            rb.velocity += Vector3.up * Physics.gravity.y * (fallMultiplier - 1) * Time.deltaTime;
        } else if (rb.velocity.y > 0 && !Input.GetKey(KeyCode.Space)) {
            rb.velocity += Vector3.up * Physics.gravity.y * (lowJumpMultiplier - 1) * Time.deltaTime;
        }
    /*}

    void Update() {*/
        float x_movement = Input.GetAxis("Horizontal");

        this.transform.Rotate(new Vector3(0, x_movement * rotationSpeed, 0), Space.Self);
        if (Input.GetKey(KeyCode.UpArrow)) {
            this.transform.Translate(Vector3.forward * moveSpeed);
        }
        else if (Input.GetKey(KeyCode.DownArrow)) {
            this.transform.Translate(Vector3.back * moveSpeed);
        }

        if (Input.GetKey(KeyCode.Space) && checkGround.isGrounded) {
            rb.velocity = Vector3.up * jumpPower;
        }
    }
}