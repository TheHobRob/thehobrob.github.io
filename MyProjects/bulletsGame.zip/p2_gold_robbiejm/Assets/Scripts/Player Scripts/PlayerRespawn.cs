﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerRespawn : MonoBehaviour
{
    Subscription<CheckpointEvent> checkpoint_event_sub;
    Subscription<RespawnEvent> respawn_event_sub;
    private bool shouldRespawn = false;
    private Vector3 lastCheckpoint;
    private Quaternion initRotation;

    void Start() {
        checkpoint_event_sub = EventBus.Subscribe<CheckpointEvent>(_UpdateRespawn);
        respawn_event_sub = EventBus.Subscribe<RespawnEvent>(_Respawn);
        lastCheckpoint = this.transform.position;
        initRotation = this.transform.rotation;
    }

    void Update() {
        if (this.transform.position.y < -20f) {
            EventBus.Publish<RespawnEvent>(new RespawnEvent());
        }
    }

    public bool checkIfShouldRespawn() {
        return shouldRespawn;
    }

    void _UpdateRespawn(CheckpointEvent e) {
        lastCheckpoint = e.position;
    }

    void _Respawn(RespawnEvent e) {
        this.transform.position = lastCheckpoint;
        this.transform.rotation = initRotation;
    }
}