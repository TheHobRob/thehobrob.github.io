﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CanCheckGround : MonoBehaviour
{
    public bool isGrounded = false;

    void Update() {
        Collider collider = this.GetComponent<Collider>();
        Ray ray = new Ray(collider.bounds.center, -this.transform.up);
        RaycastHit hit = new RaycastHit();

        float ray_distance = collider.bounds.extents.y + 0.05f;
        if (Physics.Raycast(ray, out hit, ray_distance) && hit.transform.gameObject.tag == "Platform")
            isGrounded = true;
        else
            isGrounded = false;
    }
}
