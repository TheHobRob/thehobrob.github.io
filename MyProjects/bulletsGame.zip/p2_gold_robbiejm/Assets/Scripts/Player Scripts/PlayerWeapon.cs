﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerWeapon : MonoBehaviour
{
    Subscription<ChangeBulletEvent> change_bullet_event_sub;
    public float bulletSpeed = 25f;
    public int numBullets = 3;
    private Bullet currentBullet;
    private bool machineGunMode = false;

    void Start() {
        change_bullet_event_sub = EventBus.Subscribe<ChangeBulletEvent>(_ChangeBullet);
        currentBullet = new Bullet();
    }

    void Update() {
        if (currentBullet.bulletHasElement()) {
            if (Input.GetKeyDown(KeyCode.Z) && numBullets > 0 && !machineGunMode) {
                //Debug.Log("Player shot!");
                StartCoroutine(FireBullet());
            }

            //Machine gun mode just needs to check if the player is pressing the shoot key
            if (Input.GetKey(KeyCode.Z) && numBullets > 0 && machineGunMode) {
                StartCoroutine(FireBullet());
            }
        } else {
            if (Input.GetKeyDown(KeyCode.Z)) {
                Debug.Log("Player has no weapon yet...");
            }
        }
    }

    void _ChangeBullet(ChangeBulletEvent e) {
        currentBullet.changeElementType(e.bulletElement);
        ToastManager.Toast("Obtained Weapon:\n" + currentBullet + "!");
    }

    public void ToggleMachineGunMode() {
        machineGunMode = !machineGunMode;
    }

    public Bullet getCurrentBullet() {
        return currentBullet;
    }

    IEnumerator FireBullet() {
        numBullets--;
        Vector3 playerPos = transform.position;
        Vector3 playerDirection = transform.forward;
        Quaternion playerRotation = transform.rotation;
        
        Vector3 spawnPos = playerPos + playerDirection;

        GameObject bulletClone = GameObject.Instantiate(currentBullet.getBullet(), spawnPos, playerRotation);
        bulletClone.GetComponent<Rigidbody>().velocity = transform.forward * bulletSpeed;
        yield return new WaitForSeconds(bulletClone.GetComponent<DestroyOnTime>().destroyTime);
        numBullets++;
    }
}
