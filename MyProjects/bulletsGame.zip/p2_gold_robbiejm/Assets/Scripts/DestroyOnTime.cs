﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyOnTime : MonoBehaviour
{
    public float destroyTime = 1f;

    void Start() {
        Destroy(this.gameObject, destroyTime);
    }

    public void ChangeDestroyTime(float newTime) {
        destroyTime = newTime;
    }
}
