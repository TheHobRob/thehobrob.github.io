﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MessageTrigger : MonoBehaviour
{
    public bool entered = false;
    public string[] messages;
    public float duration = 2f;
    void OnTriggerEnter(Collider other) {
        if (other.tag == "Player" && !entered) {
            entered = true;
            foreach (string message in messages) {
                Debug.Log("Sending a message...");
                EventBus.Publish<MessageEvent>(new MessageEvent(message, duration));
            }
        }
    }
}

public class MessageEvent {
    public string messageContent;
    public float duration;

    public MessageEvent(string message) {
        messageContent = message;
        duration = 2f;
    }

    public MessageEvent(string message, float duration) {
        messageContent = message;
        this.duration = duration;
    }
}