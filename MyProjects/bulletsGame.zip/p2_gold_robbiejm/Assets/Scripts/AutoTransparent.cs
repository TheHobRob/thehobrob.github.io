﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AutoTransparent : MonoBehaviour
{
    private Renderer renderer;
    private Shader oldShader;
    private Color oldColor;
    public float transperancy = 0.3f;
    public const float targetTransperancy = 0.3f;
    private const float fallOff = 0.1f;

    void Start() {
        if (this.GetComponent<Renderer>() != null) {
            renderer = this.GetComponent<Renderer>();
            BeTransparent();
        }
    }
    public void BeTransparent() {
        transperancy = targetTransperancy;
        if (oldShader == null && renderer != null) {
            oldShader = renderer.material.shader;
            oldColor = renderer.material.color;

            renderer.material.shader = Shader.Find("Transparent/Diffuse");
        }
    }

    void Update() {
        if (transperancy < 1.0f) {
            Color color = renderer.material.color;
            color.a = transperancy;
            renderer.material.color = color;
        } else {
            renderer.material.shader = oldShader;
            renderer.material.color = oldColor;
            Destroy(this);
        }
        transperancy += ((1.0f - targetTransperancy) * Time.deltaTime) / fallOff;
    }

}
