﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IsDoor : MonoBehaviour
{
    Subscription<DoorEvent> door_event_sub;
    public int doorID;

    void Start() {
        door_event_sub = EventBus.Subscribe<DoorEvent>(_TriggerDoor);
    }

    void _TriggerDoor(DoorEvent e) {
        if (e.doorID == this.doorID) {
            StartCoroutine(openDoor());
        }
    }

    IEnumerator openDoor() {
        Vector3 start_pos = this.transform.position;
        Vector3 end_pos = this.transform.position;
        end_pos.y += 5f;

        float initial_time = Time.time;
        float duration = 1f;
        float progress = (Time.time - initial_time) / duration;

        while (progress < 1.0f) {
            progress = (Time.time - initial_time) / duration;
            this.transform.position = Vector3.LerpUnclamped(start_pos, end_pos, progress);
            yield return null;
        }
    }
}