﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IsButton : MonoBehaviour
{
    public int buttonID;
    public string message;
    public float messageDuration = 2f;
    public bool isDoorButton;

    void OnCollisionEnter(Collision collisionInfo) {
        if (collisionInfo.gameObject.tag == "Bullet") {
            toggleButton();
            if (!string.IsNullOrEmpty(message)) {
                ToastManager.Toast(message, messageDuration);
            }
        }
    }

    void toggleButton() {
        if (isDoorButton)
            EventBus.Publish<DoorEvent>(new DoorEvent(buttonID));
        else
            EventBus.Publish<PlatformEvent>(new PlatformEvent(buttonID));
        this.GetComponent<Renderer>().enabled = false;
        this.GetComponent<Collider>().enabled = false;
        Vector3 new_pos = this.transform.position;
        new_pos.y = -20f;
        this.transform.position = new_pos;
    }
}
