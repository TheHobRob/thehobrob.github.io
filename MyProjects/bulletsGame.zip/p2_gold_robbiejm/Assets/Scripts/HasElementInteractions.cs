﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HasElementInteractions : MonoBehaviour
{
    private bool isBullet;
    private bool isWall;
    private bool isEnemy;
    private Element.ElementType elementType;
    private ElementInteractions elementInteractions;

    void Start() {
        this.isBullet = (this.gameObject.tag == "Bullet");
        this.isWall = (this.gameObject.tag == "Wall");
        this.isEnemy = (this.gameObject.tag == "Enemy");
        LoadElement();
    }

    void Update() {
        this.elementInteractions = new ElementInteractions();
    }

    public void LoadElement() {
        if (GetComponent<HasElement>() != null) {
            this.elementType = GetComponent<HasElement>().GetElement().getElementType();
        } else {
            Debug.Log("Error: unable to find material because this has no HasElement component!");
        }
    }

    void OnCollisionEnter(Collision collisionInfo) {
        // All objects with elements (bullets, walls, enemies) should not interact with each other if they are the same object
        if (this.gameObject.tag == collisionInfo.gameObject.tag) {
            return;
        }

        // Player bullets should not interact with player
        if (this.isBullet && collisionInfo.gameObject.tag == "Player") {
            return;
        }

        if (changeToIce(collisionInfo)) {
            this.GetComponentInParent<HasElement>().changeElement(Element.ElementType.ICE);
        }

        if (shouldDestroyThis(collisionInfo)) {
            if (collisionInfo.gameObject.GetComponent<CanRespawn>() == null) {
                Destroy(this.gameObject);
            }
        }
    }

    bool shouldDestroyThis(Collision col) {
        // If the item you're colliding with has no element, just destroy this on collision if you're a bullet
        // (It might just be a regular wall)
        if (col.gameObject.GetComponent<HasElement>() == null) {
            //Debug.Log("BULLET DESTORYED DUE TO NO ELEMENT CONTACT");
            if (isBullet) {
                return true;
            }
            return false;
        }
        Element.ElementType aObject = this.elementType;
        Element.ElementType bObject = col.gameObject.GetComponent<HasElement>().GetElement().getElementType();

        //Debug.Log("CHECK COLLISION: " + (int)aObject + ", " + (int)bObject);

        // A bullet gets destroyed a different way from a wall
        if (this.isBullet) {
            return true;/*elementInteractions.checkAttack(aObject, bObject);*/
        }
        // If you're not a bullet (most likely a wall) check if you're affected by the collision
        return elementInteractions.checkDefense(bObject, aObject);
    }

    bool changeToIce(Collision col) {
        if (col.gameObject.GetComponent<HasElement>() == null) {
            return false;
        }

        Element.ElementType aObject = this.elementType;
        Element.ElementType bObject = col.gameObject.GetComponent<HasElement>().GetElement().getElementType();
        if (this.isWall && aObject == Element.ElementType.WATER
            && col.gameObject.tag == "Bullet" && bObject == Element.ElementType.ICE) {
                return true;
            }

        return false;
    }
}
