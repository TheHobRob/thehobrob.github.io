﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IsWeaponUpgrade : MonoBehaviour
{
    public Upgrade upgrade;
    void OnTriggerEnter(Collider other) {
        if (other.tag == "Player") {
            if (upgrade == Upgrade.MOREBULLET) {
                other.GetComponent<PlayerWeapon>().numBullets = 10;

                ToastManager.Toast("Weapon Upgrade: More Bullets");
                ToastManager.Toast("You can fire up to 10 bullets at once!", 3f);
            }

            if (upgrade == Upgrade.MACHINEGUN) {
                other.GetComponent<PlayerWeapon>().ToggleMachineGunMode();

                ToastManager.Toast("Weapon Upgrade: Machine Gun");
                ToastManager.Toast("Now you can hold the Z key to shoot several bullets!", 3f);
            }

            Destroy(this.gameObject);
        }
    }

    public enum Upgrade {
        MOREBULLET, MACHINEGUN
    }
}
