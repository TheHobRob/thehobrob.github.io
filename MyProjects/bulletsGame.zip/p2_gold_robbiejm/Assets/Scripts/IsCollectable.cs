﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(IsFloating))]
public class IsCollectable : MonoBehaviour
{
    public bool isDestructible = true;
    private Element.ElementType bulletTypeUpgrade;
    private bool hasElement;

    void Start() {
        this.hasElement = (GetComponent<HasElement>() != null);
        if (this.hasElement) {
            bulletTypeUpgrade = GetComponent<HasElement>().GetElement().getElementType();
        }
    }

    void OnTriggerEnter(Collider other) {
        if (other.tag == "Player") {
            //Debug.Log("Collectible collided with player!");
            if (this.hasElement && !other.GetComponent<PlayerWeapon>().getCurrentBullet().checkIfThisElement(this.bulletTypeUpgrade))
                EventBus.Publish<ChangeBulletEvent>(new ChangeBulletEvent(bulletTypeUpgrade));

            if (this.isDestructible) {
                Destroy(this.gameObject);
            }
        }
    }
}
