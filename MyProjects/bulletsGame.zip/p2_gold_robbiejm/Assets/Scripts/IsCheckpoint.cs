﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IsCheckpoint : MonoBehaviour
{
    Subscription<CheckpointEvent> checkpoint_event_sub;
    public int checkpointID;

    void Start() {
        checkpoint_event_sub = EventBus.Subscribe<CheckpointEvent>(_TriggerCheckpoint);
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player") {
            EventBus.Publish<CheckpointEvent>(new CheckpointEvent(this.checkpointID, this.transform.position + Vector3.up));
        }
    }

    void _TriggerCheckpoint(CheckpointEvent e) {
        if (e.checkpointID == this.checkpointID) {
            StartCoroutine(DoCheckpoint());
        }
    }

    IEnumerator DoCheckpoint() {
        yield return null;
    }
}
