﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet
{
    private Element element;
    private bool hasElement;

    public Bullet() {
        hasElement = false;
    }
    public Bullet(Element.ElementType element) {
        this.element = new Element(element);
        hasElement = true;
    }

    public GameObject getBullet() {
        GameObject newBullet = null;
        if (hasElement) {
            newBullet = Resources.Load("BulletPrefabs/" + element.ToString() + "Bullet", typeof(GameObject)) as GameObject;
            //Debug.Log("Returning Bullet gameobject with element " + element.ToString());
        }
        return newBullet;
    }

    public bool bulletHasElement() {
        return hasElement;
    }

    public void changeElementType(Element.ElementType newElement) {
        this.element = new Element(newElement);
        hasElement = true;
        //Debug.Log("Changed bullet element to " + this.element);
    }

    public bool checkIfThisElement(Element.ElementType e) {
        if (hasElement)
            return this.element.getElementType() == e;
        return false;
    }

    public override string ToString() {
        return this.element.ToString() + " Bullet";
    }
}
