﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Element
{
    private ElementType elementType;

    public Element(ElementType element) {
        this.elementType = element;
    }

    public void changeElement(ElementType newElement) {
        this.elementType = newElement;
    }

    public ElementType getElementType() {
        return elementType;
    }

    public override string ToString() {
        return this.elementType.ToString();
    }

    public enum ElementType {
        NORMAL = 0, 
        FIRE = 1, 
        ICE = 2, 
        WATER = 3, 
        ELECTRIC = 4, 
        WIND = 5
    }
}
