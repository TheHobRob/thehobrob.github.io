﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ElementInteractions
{
    // Attack chart: [Element of bullet, Element of object it's clashing]
    // this returns whether a bullet should be destroyed after coming in contact with something
    private bool[,] attackChart = new bool[6, 6] {
        {true, true, true, false, true, false}, //NORMAL
        {true, true, false, true, true, true},  //FIRE
        {true, true, true, false, true, false}, //ICE
        {true, false, true, true, true, false}, //WATER
        {true, true, true, true, true, false},  //ELECTRIC
        {true, true, true, true, true, true}    //ICE
    };

    // Defense chart: [Element of object, Element of object it's clashing]
    // this returns whether this object should be destroyed after coming in contact with something
    private bool[,] defendChart = new bool[6, 6] {
        {false, false, false, false, false, false}, //NORMAL
        {false, false, true, false, false, false},  //FIRE
        {false, false, false, false, false, false}, //ICE
        {false, true, false, false, false, false},  //WATER
        {false, false, false, false, false, false}, //ELECTRIC
        {false, true, false, true, false, true}     //WIND
    };

    public ElementInteractions() {}

    public bool checkAttack(Element.ElementType attacker, Element.ElementType defender) {
        return this.attackChart[(int)attacker, (int)defender];
    }
    public bool checkDefense(Element.ElementType attacker, Element.ElementType defender) {
        return this.defendChart[(int)attacker, (int)defender];
    }
}
