﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    static GameManager instance;
    Subscription<MessageEvent> message_event_sub;
    Subscription<CheckpointEvent> checkpoint_event_sub;

    // Use this for initialization
    void Awake() {
        // Typical singleton initialization code.
        if (instance != null && instance != this) {
            // If there already exists a CameraManager, we need to go away.
            Destroy(gameObject);
            return;
        } else {
            // If we are the first CameraManager, we claim the "instance" variable so others go away.
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
    }

    void Start() {
        message_event_sub = EventBus.Subscribe<MessageEvent>(_PushMessage);
    }


    void _PushMessage(MessageEvent e) {
        Debug.Log("...message received!");
        ToastManager.Toast(e.messageContent, e.duration);
    }
}

// Called whenever a door is opened
public class DoorEvent {
    public int doorID;
    public DoorEvent(int doorID) {
        this.doorID = doorID;
    }
}

// Called whenever a platform is activated
public class PlatformEvent {
    public int platformID;

    public PlatformEvent(int platformID) {
        this.platformID = platformID;
    }
}

// Called whenever the player bullet is changed

public class ChangeBulletEvent {
    public Element.ElementType bulletElement;
    public ChangeBulletEvent(Element.ElementType newBulletElement) {
        this.bulletElement = newBulletElement;
    }
}

// Called whenever the player's checkpoint is updated
public class CheckpointEvent {
    public int checkpointID;
    public Vector3 position;

    public CheckpointEvent(int checkpointID, Vector3 position) {
        this.checkpointID = checkpointID;
        this.position = position;
    }
}

// Called whenever the player needs to respawn
public class RespawnEvent {
    public RespawnEvent() {}
}