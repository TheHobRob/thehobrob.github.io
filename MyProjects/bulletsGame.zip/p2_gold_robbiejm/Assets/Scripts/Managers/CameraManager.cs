﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraManager : MonoBehaviour {
    static CameraManager instance;
    public Vector3 lastDirection;
    public Vector3 lastPosition;
    public Vector3 currentDirection;
    public Transform target;
    private Vector3 camVelocity = Vector3.zero;
    [Range(0.01f, 1.0f)]
    public float smoothFactor = 0.1f;
    private Vector3 offset;

    Subscription<CheckpointEvent> checkpoint_event_sub;
    Subscription<RespawnEvent> respawn_event_sub;

    // Use this for initialization
    void Awake() {
        // Typical singleton initialization code.
        if (instance != null && instance != this) {
            // If there already exists a CameraManager, we need to go away.
            Destroy(gameObject);
            return;
        } else {
            // If we are the first CameraManager, we claim the "instance" variable so others go away.
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
    }

    void Start() {
        checkpoint_event_sub = EventBus.Subscribe<CheckpointEvent>(_UpdateRespawn);
        respawn_event_sub = EventBus.Subscribe<RespawnEvent>(_Respawn);
        ChangeCameraTarget(target);
        offset = transform.position - target.position;
    }

    void Update() {
        float dist = Vector3.Distance(transform.position, target.transform.position) - 0.5f;
        RaycastHit[] hits;
        hits = Physics.RaycastAll(transform.position, transform.forward, dist);

        foreach (RaycastHit h in hits) {
            // make them semitransparent
            Renderer rend = h.collider.GetComponent<Renderer>();

            if (rend == null) continue;
            
            AutoTransparent AT = rend.GetComponent<AutoTransparent>();
            if (h.transform.tag != "Player" && h.transform.tag != "Collectible" && AT == null) {
                AT = (AutoTransparent)rend.gameObject.AddComponent(typeof(AutoTransparent));
            }

            if (rend.GetComponent<AutoTransparent>() != null) AT.BeTransparent();
        }
    }

    void LateUpdate() {
        if (target != null) {
            Vector3 newPos = target.position + offset;
            transform.position = Vector3.Slerp(transform.position, newPos, smoothFactor);
            transform.LookAt(target);
        }
    }

    public static void ChangeCameraTarget(Transform newTarget) {
        instance.target = newTarget;
    }

    public static Vector3 GetCurrentCameraDirection() {
        return instance.currentDirection;
    }

    void _UpdateRespawn(CheckpointEvent e) {
        lastDirection = currentDirection;
        lastPosition = this.transform.position;
    }

    void _Respawn(RespawnEvent e) {
        this.transform.position = lastPosition;
        currentDirection = lastDirection;
    }
}
