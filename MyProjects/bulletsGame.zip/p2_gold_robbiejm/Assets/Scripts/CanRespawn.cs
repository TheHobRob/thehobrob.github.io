﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CanRespawn : MonoBehaviour
{
    public float rateOfRespawn = 3f;
    public Vector3 offset = new Vector3(0f, -5f, 0f);
    private ElementInteractions elementInteractions;

    void Start()
    {
        elementInteractions = new ElementInteractions();
    }
    void OnCollisionEnter(Collision collisionInfo) {
        if (collisionInfo.gameObject.tag == "Bullet" && 
                elementInteractions.checkDefense(
                    collisionInfo.gameObject.GetComponent<HasElement>().GetElement().getElementType(), 
                    this.GetComponent<HasElement>().GetElement().getElementType())) {
            StartCoroutine(DeactivateForAwhile());
        }
    }

    IEnumerator DeactivateForAwhile() {
        /*Vector3 end_pos = this.transform.position;
        Vector3 start_pos = end_pos + offset;*/
        this.gameObject.GetComponent<Renderer>().enabled = false;
        this.gameObject.GetComponent<Collider>().enabled = false;
        Debug.Log("Object has been deactivated... (waiting for " + (int)rateOfRespawn + " s)");

        yield return new WaitForSeconds(rateOfRespawn);
        
        this.gameObject.GetComponent<Renderer>().enabled = true;
        this.gameObject.GetComponent<Collider>().enabled = true;
        Debug.Log("Object has been reactivated!");

        /*float initial_time = Time.time;
        float duration = 1f;
        float progress = (Time.time - initial_time) / duration;

        while (progress < 1.0f) {
            progress = (Time.time - initial_time) / duration;
            this.transform.position = Vector3.LerpUnclamped(start_pos, end_pos, progress);
        }*/
    }
}
