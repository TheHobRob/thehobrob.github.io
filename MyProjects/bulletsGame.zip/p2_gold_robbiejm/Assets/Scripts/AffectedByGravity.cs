﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AffectedByGravity : MonoBehaviour
{
    private bool rotating = false;
    void Update() {
        // Rotation action
        if (Input.GetKey(KeyCode.LeftShift)) {
            if (Input.GetKey(KeyCode.A) && !rotating) {
                StartCoroutine(Rotation(RotationDirection.Clockwise));
            } else if (Input.GetKey(KeyCode.D) && !rotating) {
                StartCoroutine(Rotation(RotationDirection.Counterclockwise));
            }
        }
    }

    IEnumerator Rotation(RotationDirection dir) {
        rotating = true;
        float rotation_speed = 10f;
        Vector3 rotate_dir = GetRotationDirection(dir);

        for (int i = 0; i <= 90; i += (int)rotation_speed) {
            this.transform.Rotate(rotate_dir / rotation_speed);
            yield return new WaitForSeconds(0.5f / rotation_speed);
        }
        yield return new WaitForSeconds(0.2f);
        rotating = false;
    }

    enum RotationDirection {
        Left                = 0,
        Right               = 1,
        Forward             = 2,
        Backward            = 3,
        Clockwise           = 4,
        Counterclockwise    = 5,
    }

    Vector3 GetRotationDirection(RotationDirection rd) {
        Vector3 ret = Vector3.zero;
        if (rd == RotationDirection.Left) {
            ret =  Vector3.up;
        } else if (rd == RotationDirection.Right) {
            ret =  Vector3.down;
        } else if (rd == RotationDirection.Forward) {
            ret =  Vector3.right;
        } else if (rd == RotationDirection.Backward) {
            ret =  Vector3.left;
        } else if (rd == RotationDirection.Clockwise) {
            ret =  Vector3.back;
        } else if (rd == RotationDirection.Counterclockwise) {
            ret =  Vector3.forward;
        }
        return ret * 90;
    }
}
