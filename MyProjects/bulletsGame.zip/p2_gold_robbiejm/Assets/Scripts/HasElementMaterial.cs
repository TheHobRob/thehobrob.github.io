﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HasElementMaterial : MonoBehaviour
{
    public bool isGlass;
    
    void Start() {
        LoadMaterial();
    }

    public void LoadMaterial() {
        if (GetComponent<HasElement>() != null) {
            string element = GetComponent<HasElement>().GetElement().ToString();
            string type = "Solid";
            if (isGlass)
                type = "Glass";
            //Debug.Log("Gameobject loaded with material " + element + type);
            GetComponent<Renderer>().material = Resources.Load("Material/" + element + type, typeof(Material)) as Material;
        } else {
            Debug.Log("Error: unable to find material because this has no HasElement component!");
        }
    }
}
