﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatformMovement : MonoBehaviour
{
    Subscription<PlatformEvent> platform_event_sub;
    public int platformID;
    public Vector3[] points;
    private int point_number = 0;
    private float tolerance;
    public float speed;
    public float delayTime;
    public bool automatic;
    private bool isMoving;
    private Vector3 init_pos;
    private Vector3 current_target;

    void Start() {
        init_pos = this.transform.localPosition;
        platform_event_sub = EventBus.Subscribe<PlatformEvent>(_TriggerPlatform);

        if (points.Length > 0) {
            current_target = getPoint(0);
        }
        tolerance = speed * Time.deltaTime;
        isMoving = true;
    }
    void FixedUpdate() {
        if (isMoving) {
            if (transform.localPosition != current_target) {
                movePlatform();
            } else {
                updateTarget();
            }
        }
    }

    void togglePlatform() {
        automatic = !automatic;
        updateTarget();
    }

    void movePlatform() {
        Vector3 heading = current_target - transform.localPosition;
        transform.localPosition += (heading/heading.magnitude) * speed * Time.deltaTime;
        if (heading.magnitude < tolerance) {
            transform.localPosition = current_target;
        }
    }

    void updateTarget() {
        isMoving = false;
        if (automatic) {
            StartCoroutine(Pause());
        }
    }

    Vector3 getPoint(int num) {
        return points[num] + init_pos;
    }

    public void nextPlatform() {
        point_number++;
        if (point_number >= points.Length) {
            point_number = 0;
        }
        current_target = getPoint(point_number);
    }

    void _TriggerPlatform(PlatformEvent e) {
        if (this.platformID == e.platformID) {
            togglePlatform();
        }
    }

    IEnumerator Pause() {
        yield return new WaitForSeconds(delayTime);
        nextPlatform();
        isMoving = true;
    }
}
